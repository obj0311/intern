# MartianAI CLI
## Usage
```
MartianAICli.exe [-i|--inferencemode] inferencemode [-s|--size] size [-c|--cpu] [-g|--gpuid] gpuid [-f|--file] <input_file>
```
