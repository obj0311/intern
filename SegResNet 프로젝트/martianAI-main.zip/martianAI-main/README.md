# dev-martianAI
Standalone MartianAI Inference Project(32bit MFC Host exe&lt;->32 bit dll Wrapper&lt;->64bit MartianAI Inference exe)

![ui](https://media.github.sec.samsung.net/user/89495/files/ce73da52-e255-46e9-bc33-d52c4a6727bb)

필요사항

 - Wiki 참조
